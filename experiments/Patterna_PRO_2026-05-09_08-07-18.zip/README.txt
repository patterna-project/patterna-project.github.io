============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 9. 5. 2026 8:07:18
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: NIE
Vynútený štartovací vzor: Žiadny

SEKVENCIA
----------------------------------------
1. stable roles
   Súbor: stable_roles.txt
   Katalóg: CoH
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

2. few roles
   Súbor: few_roles.txt
   Katalóg: CoH
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

3. distribute work evenly
   Súbor: distribute_work_evenly.txt
   Katalóg: CoH
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

4. hallway chatter
   Súbor: hallway_chatter.txt
   Katalóg: CoH
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

5. move responsibilites
   Súbor: move_responsibilites.txt
   Katalóg: CoH
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

ŠTATISTIKY
----------------------------------------
Počet vzorov: 5
Priemerná podobnosť v sekvencii: 82.0%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií vzorov na základe protichodných síl.
============================================================