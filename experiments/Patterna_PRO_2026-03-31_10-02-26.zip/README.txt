============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 31. 3. 2026 10:02:26
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: ÁNO
Vynútený štartovací vzor: Žiadny

SEKVENCIA
----------------------------------------
1. wise fool
   Súbor: wise_fool.txt
   Katalóg: moje
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

2. public character
   Súbor: public_character.txt
   Katalóg: moje
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

3. gate keeper
   Súbor: gate_keeper.txt
   Katalóg: moje
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

4. fire walls
   Súbor: fire_walls.txt
   Katalóg: moje
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

ŠTATISTIKY
----------------------------------------
Počet vzorov: 4
Priemerná podobnosť v sekvencii: 51.8%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================