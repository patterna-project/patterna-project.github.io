============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 23. 4. 2026 19:45:00
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.85
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: NIE
Vynútený štartovací vzor: mediator.txt

SEKVENCIA
----------------------------------------
1. mediator
   Súbor: mediator.txt
   Katalóg: GoF
   Jazyk/Sekcia: Behavioral_Patterns

2. observer
   Súbor: observer.txt
   Katalóg: GoF
   Jazyk/Sekcia: Behavioral_Patterns

ŠTATISTIKY
----------------------------------------
Počet vzorov: 2
Priemerná podobnosť v sekvencii: 47.2%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================