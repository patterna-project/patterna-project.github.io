============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 23. 4. 2026 19:55:59
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: NIE
Vynútený štartovací vzor: Žiadny

SEKVENCIA
----------------------------------------
1. composite
   Súbor: composite.txt
   Katalóg: GoF
   Jazyk/Sekcia: Structural_Patterns

2. decorator
   Súbor: decorator.txt
   Katalóg: GoF
   Jazyk/Sekcia: Structural_Patterns

ŠTATISTIKY
----------------------------------------
Počet vzorov: 2
Priemerná podobnosť v sekvencii: 47.6%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================