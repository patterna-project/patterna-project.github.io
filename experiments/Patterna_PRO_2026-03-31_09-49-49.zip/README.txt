============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 31. 3. 2026 9:49:49
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: ÁNO
Vynútený štartovací vzor: Žiadny

SEKVENCIA
----------------------------------------
1. stable roles
   Súbor: stable_roles.txt
   Katalóg: moje
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

2. producer roles
   Súbor: producer_roles.txt
   Katalóg: moje
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

3. form follows function
   Súbor: form_follows_function.txt
   Katalóg: moje
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

ŠTATISTIKY
----------------------------------------
Počet vzorov: 3
Priemerná podobnosť v sekvencii: 56.5%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================