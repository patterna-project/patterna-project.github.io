============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 15. 4. 2026 9:42:24
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: NIE
Vynútený štartovací vzor: Žiadny

SEKVENCIA
----------------------------------------
1. surrogate customer
   Súbor: surrogate_customer.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

2. engage customers
   Súbor: engage_customers.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

3. engage quality assurance
   Súbor: engage_quality_assurance.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

4. application design is bounded by test design
   Súbor: application_design_is_bounded_by_test_design.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

5. scenarios define problem
   Súbor: scenarios_define_problem.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

6. diverse groups
   Súbor: diverse_groups.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

7. holistic diversity
   Súbor: holistic_diversity.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

8. team pride
   Súbor: team_pride.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

ŠTATISTIKY
----------------------------------------
Počet vzorov: 8
Priemerná podobnosť v sekvencii: 56.0%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================