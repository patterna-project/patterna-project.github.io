============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 8. 4. 2026 13:36:57
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: NIE
Vynútený štartovací vzor: Žiadny

SEKVENCIA
----------------------------------------
1. hierarchy of factories
   Súbor: hierarchy_of_factories.txt
   Katalóg: C and H
   Jazyk/Sekcia: People_and_Code_Pattern_Language

2. parser builder
   Súbor: parser_builder.txt
   Katalóg: C and H
   Jazyk/Sekcia: People_and_Code_Pattern_Language

3. prototype
   Súbor: prototype.txt
   Katalóg: design
   Jazyk/Sekcia: Creational_Patterns

ŠTATISTIKY
----------------------------------------
Počet vzorov: 3
Priemerná podobnosť v sekvencii: 56.9%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================