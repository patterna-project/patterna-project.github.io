============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 31. 3. 2026 20:06:22
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: NIE
Vynútený štartovací vzor: Žiadny

SEKVENCIA
----------------------------------------
1. the water cooler
   Súbor: the_water_cooler.txt
   Katalóg: hhh
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

2. hallway chatter
   Súbor: hallway_chatter.txt
   Katalóg: hhh
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

3. responsibilities engage
   Súbor: responsibilities_engage.txt
   Katalóg: hhh
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

4. producers in the middle
   Súbor: producers_in_the_middle.txt
   Katalóg: hhh
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

5. producer roles
   Súbor: producer_roles.txt
   Katalóg: hhh
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

6. few roles
   Súbor: few_roles.txt
   Katalóg: hhh
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

7. three to seven helpers per role
   Súbor: three_to_seven_helpers_per_role.txt
   Katalóg: hhh
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

8. distribute work evenly
   Súbor: distribute_work_evenly.txt
   Katalóg: hhh
   Jazyk/Sekcia: Organizational_Style_Pattern_Language

ŠTATISTIKY
----------------------------------------
Počet vzorov: 8
Priemerná podobnosť v sekvencii: 68.8%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================