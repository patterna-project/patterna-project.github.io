============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 8. 4. 2026 12:58:54
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: NIE
Vynútený štartovací vzor: team_pride.txt

SEKVENCIA
----------------------------------------
1. team pride
   Súbor: team_pride.txt
   Katalóg: C and H
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

2. stable teams
   Súbor: stable_teams.txt
   Katalóg: Scrum
   Jazyk/Sekcia: Product_Organization_Pattern_Language

3. mitosis
   Súbor: mitosis.txt
   Katalóg: Scrum
   Jazyk/Sekcia: Product_Organization_Pattern_Language

4. crossfunctional team
   Súbor: crossfunctional_team.txt
   Katalóg: Scrum
   Jazyk/Sekcia: Product_Organization_Pattern_Language

5. conways law
   Súbor: conways_law.txt
   Katalóg: Scrum
   Jazyk/Sekcia: Product_Organization_Pattern_Language

ŠTATISTIKY
----------------------------------------
Počet vzorov: 5
Priemerná podobnosť v sekvencii: 77.2%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================