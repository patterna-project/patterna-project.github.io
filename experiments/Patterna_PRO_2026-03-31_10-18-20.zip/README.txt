============================================================
                   PATTERNA - PRO EXPORT                    
============================================================

Dátum exportu: 31. 3. 2026 10:18:20
Verzia aplikácie: 1.0.3

PARAMETRE GENEROVANIA
----------------------------------------
γ (gamma): 0.9
R(g) - odmena za cieľ: 10
R(o) - odmena za ostatné: 1
ε (epsilon): 0.1
IDF: NIE
Sentiment analýza: NIE
Vynútený štartovací vzor: Žiadny

SEKVENCIA
----------------------------------------
1. architecture team
   Súbor: architecture_team.txt
   Katalóg: moje
   Jazyk/Sekcia: People_and_Code_Pattern_Language

2. lock ’em up together
   Súbor: lock_’em_up_together.txt
   Katalóg: moje
   Jazyk/Sekcia: People_and_Code_Pattern_Language

3. unity of purpose
   Súbor: unity_of_purpose.txt
   Katalóg: moje
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

4. team pride
   Súbor: team_pride.txt
   Katalóg: moje
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

5. self selecting team
   Súbor: self_selecting_team.txt
   Katalóg: moje
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

6. holistic diversity
   Súbor: holistic_diversity.txt
   Katalóg: moje
   Jazyk/Sekcia: Piecemeal_Growth_Pattern_Language

7. team per task
   Súbor: team_per_task.txt
   Katalóg: moje
   Jazyk/Sekcia: Project_Management_Pattern_Language

8. sacrifice one person
   Súbor: sacrifice_one_person.txt
   Katalóg: moje
   Jazyk/Sekcia: Project_Management_Pattern_Language

9. someone always makes progress
   Súbor: someone_always_makes_progress.txt
   Katalóg: moje
   Jazyk/Sekcia: Project_Management_Pattern_Language

10. get on with it
   Súbor: get_on_with_it.txt
   Katalóg: moje
   Jazyk/Sekcia: Project_Management_Pattern_Language

ŠTATISTIKY
----------------------------------------
Počet vzorov: 10
Priemerná podobnosť v sekvencii: 60.7%

OBSAH ARCHÍVU
----------------------------------------
README.txt            - tento súbor s popisom
metadata.json         - všetky dáta v JSON formáte (parametre, matica, MDP, atď.)
patterns/             - priečinok s kompletnými textami všetkých vzorov
outputs/              - priečinok s výstupmi v čitateľných formátoch
  sequence.txt        - sekvencia ako text
  similarity_matrix.csv - matica podobností v CSV
  mdp_steps.txt       - detailný postup MDP riešenia

============================================================
Vygenerované pomocou Patterna - nástroj pre analýzu a generovanie
sekvencií organizačných vzorov na základe protichodných síl.
============================================================